function [ Out ] = FeatCompNew( img )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
mapping=getmapping(8,'u2');
[CLBP_SH, CLBP_MH]=clbp(img,1,8,mapping,'h');
Out=[CLBP_SH CLBP_MH];
end

