function Gabor_Feat=ILD_Gabor(img,K,N);
[gaborSquareEnergy, gaborMeanAmplitude ]= phasesym(img, K, N);
Gabor_Feat=[gaborSquareEnergy gaborMeanAmplitude];