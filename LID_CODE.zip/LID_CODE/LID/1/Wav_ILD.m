function [Wav_Feat] = Wav_ILD(img)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
RID=img;
feat1 = single(EstraiWAVE(RID,'haar'));

%%%%%%%%% DB4
feat2 = single(EstraiWAVE(RID,'db4'));

%%%%%%%%% COI
feat3 = single(EstraiWAVE(RID,'coif2'));
Wav_Feat=[feat1 feat2 feat3];
end

