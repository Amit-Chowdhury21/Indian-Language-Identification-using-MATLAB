Computation of Gabor Features - Mean Squared Energy, Mean Amplitude

>>> im = rgb2gray(imread( '001.png' ));
>>> [gaborSquareEnergy, gaborMeanAmplitude ]= phasesym(im);

Contact : Manohar Kuse (swaroopcool21@gmail.com)



The matlab function to use gabo filters is [gaborSquareEnergy, gaborMeanAmplitude ]= phasesym(ig, 5, 14);