function [lbp_hf_features ] = LBP_EHF(img)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
I=img;
I2=imrotate(img,90);
mapping=getmaplbphf(8);
h=lbp(I,1,8,mapping,'h');
h=h/sum(h);
histograms(1,:)=h;
h=lbp(I2,1,8,mapping,'h');
h=h/sum(h);
histograms(2,:)=h;
lbp_hf_features=constructhf(histograms,mapping);
lbp_hf_features=[lbp_hf_features(1,:) lbp_hf_features(2,:)];

end

