function [featurevectors1]=constructhfVARsel(inputvectors, map, metodo)
%construct rotation invariant features from uniform LBP histogram
%inputvectors: NxD array, N histograms of D bins each
%map: mapping struct from getmaphf
%
%EXAMPLE:
%I=imread('rice.png');
%I2=imrotate(I,90);
%mapping=getmaplbphf(8);
%h=lbp(I,1,8,mapping,'h');
%h=h/sum(h);
%histograms(1,:)=h;
%h=lbp(I2,1,8,mapping,'h');
%h=h/sum(h);
%histograms(2,:)=h;
%lbp_hf_features=constructhf(histograms,mapping);
%
%The two rows of lbp_hf_features now contain LBP
%histogram Fourier feature vectors of rice.png and
%its rotated version (with LBP radius 1 and 8 sampling
%points)


n=map.samples;
FVLEN=(n-1)*(floor(n/2)+1)+3;
featurevectors1=single(zeros(size(inputvectors,1),FVLEN));

if metodo==1
    
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            b=fft(b')';
            b=abs(b);
            b=b(:,1:(floor(size(b,2)/2)+1));
        end
        featurevectors1(:,k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==2
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            b=dct(b')';
            b=abs(b);
            b=b(:,1:(floor(size(b,2)/2)+1));
        end
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==3
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            [b,cd] = dwt(b,'db4','mode','sym');
            b=fft(b')';
            b=abs(b);
            b=b(:,1:(floor(size(b,2)/2)+1));
        end
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==4
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            [b,cd] = dwt(b,'db4','mode','sym');
            b=dct(b')';
            b=abs(b);
            b=b(:,1:(floor(size(b,2)/2)+1));
        end
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==5
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            [b,cd] = dwt(b,'db4','mode','sym');
            b=fft(b')';
            b=abs(b);
        end
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==6
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        if(size(b,2) > 1)
            [b,cd] = dwt(b,'db4','mode','sym');
            b=dct(b')';
            b=abs(b);
        end
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
    
elseif metodo==7
    k=1;
    for j=1:length(map.orbits)
        b=inputvectors(:,map.orbits{j}+1);
        featurevectors1(k:k+size(b,2)-1)=single(b);
        k=k+size(b,2);
    end
end

