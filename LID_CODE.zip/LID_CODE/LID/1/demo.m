im=imread('sample.pgm');
MFS=LapMFS(im);