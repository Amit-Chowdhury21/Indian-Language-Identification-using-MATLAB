%% This script helps you to extract features from 
clc;
clear all;
close all;
warning off;
%%
%%
cd('1');
AudioFile = dir('*.wav');
for k = 1:length(AudioFile)
filename = AudioFile(k).name;
[y1,Fs] = wavread(filename);
y1= y1(1:Fs*4);
spectrogram(y1, 600, [], [],Fs, 'yaxis');
waterfall(y1);

%colormap(gray)
set(gca,'XTick',[]); % Remove the ticks in the x axis!
set(gca,'YTick',[]); % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]); % Make the axes occupy the hole figure
axis xy;
 
 saveas(gcf,'English','jpg');
% img=imread('English.jpg');
% img=rgb2gray(img);
 clf;
%close all;
% 
%CLBP(k,:) = FeatCompNew(img);
%Features(k,:) = getFeatures(I);
end
cd('C:\Users\AMIT\Videos\LID\LID');